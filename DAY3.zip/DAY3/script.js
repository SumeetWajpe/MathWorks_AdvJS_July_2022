function Initialize() {
  // fetch -> http://localhost:3000/courses

  for (let course of courses) {
    CourseCardItem(course);
  }
}

function CourseCardItem(course) {
  let courseCard = document.createElement("div");
  courseCard.className = "card m-2 p-0";
  courseCard.style.width = "18rem";
  courseCard.id = course.id;

  let courseCardImage = document.createElement("img");
  courseCardImage.src = course.imageUrl;
  courseCardImage.alt = course.title;
  courseCardImage.className = "card-img-top";
  courseCardImage.style.height = "150px";

  let courseCardBody = document.createElement("div");
  courseCardBody.setAttribute("class", "card-body");

  var ratings = document.createElement("p");

  for (let index = 0; index < course.rating; index++) {
    ratings.innerHTML += `<i class="fa-solid fa-star" style="color:orange"></i>`;
  }

  let courseTitle = document.createElement("h5");
  courseTitle.innerText = course.title;
  courseTitle.className = "card-title";

  let coursePrice = document.createElement("p");
  coursePrice.innerText = course.price;
  coursePrice.className = "card-text";

  let courseLikesBtn = document.createElement("button");
  courseLikesBtn.className = "btn btn-primary";
  //courseLikesBtn.innerText = course.likes;
  courseLikesBtn.innerHTML = `<i class="fa-solid fa-thumbs-up"></i> ${course.likes}`;

  let courseDeleteBtn = document.createElement("button");
  courseDeleteBtn.className = "btn btn-danger mx-1";
  courseDeleteBtn.innerHTML = `<i class="fa-solid fa-trash"></i>`;
  courseDeleteBtn.addEventListener("click", DeleteCourse.bind(null, course));
  //OR
  // courseDeleteBtn.addEventListener("click", function () {
  //   DeleteCourse(course);
  // });

  courseCardBody.append(ratings);
  courseCardBody.append(courseTitle);
  courseCardBody.append(coursePrice);
  courseCardBody.append(courseLikesBtn);
  courseCardBody.append(courseDeleteBtn);

  courseCard.append(courseCardImage);
  courseCard.append(courseCardBody);

  document.getElementById("courseList").append(courseCard);
}

function DeleteCourse(course) {
  let courseToBeDeleted = document.getElementById(course.id);
  courseToBeDeleted.remove();
}

function AddNewCourse() {
  // HTML 5
  // new
  let allInputs = document.querySelectorAll("input");
  let newCourseToBeAdded = Array.from(allInputs).reduce(
    (newCourse, input) => ({
      ...newCourse,
      [input.id]: input.value,
    }),
    {},
  );

  console.log(newCourseToBeAdded);
  CourseCardItem(newCourseToBeAdded);
  document.querySelector("#newCourseForm").reset();
}

window.addEventListener("DOMContentLoaded", Initialize);
