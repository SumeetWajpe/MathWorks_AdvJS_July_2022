class Tooltip extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" }); // enable shadow DOM !
  }

  connectedCallback() {
    let tooltipIcon = document.createElement("span");
    tooltipIcon.innerText = "(?)";
    tooltipIcon.addEventListener("mouseenter",this.showTooltip);
    tooltipIcon.addEventListener("mouseleave", this.hideTooltip);

    this.shadowRoot.append(tooltipIcon);
  }

  showTooltip(){
    console.log("Showing tooltip..")
  }

  hideTooltip(){
    console.log("Hiding tooltip..")
  }
}

customElements.define("uc-tooltip", Tooltip);
