function GetData(callback) {
  let xmlhttpReq = new XMLHttpRequest();
  xmlhttpReq.open("GET", "https://jsonplaceholder.typicode.com/posts");
  xmlhttpReq.onreadystatechange = function () {
    if (xmlhttpReq.readyState == 4 && xmlhttpReq.status == 200) {
      callback(null, xmlhttpReq.responseText);
    } else if (xmlhttpReq.readyState == 4 && xmlhttpReq.status !== 200) {
      callback(xmlhttpReq.status, null);
    }
  };
  xmlhttpReq.send(); // places an async call
}
