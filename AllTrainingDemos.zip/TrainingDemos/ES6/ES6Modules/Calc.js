import * as MathModule from './Math.js'
console.log("The addition is : " + MathModule.default(30, 40));
console.log("The product is : " + MathModule. Product(30, 40));

