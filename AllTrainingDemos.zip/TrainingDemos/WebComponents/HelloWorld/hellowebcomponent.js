class HelloWebComponent extends HTMLElement {
  constructor() {
    super();
    console.log("Hello from Web Component !");
  }
}

customElements.define("hello-webcomponent", HelloWebComponent);
