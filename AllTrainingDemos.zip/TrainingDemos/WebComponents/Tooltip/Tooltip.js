class Tooltip extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" }); // enable shadow DOM !
    this.tooltip = null;
  }

  connectedCallback() {
    let tooltipIcon = document.createElement("span");
    tooltipIcon.innerText = "(?)";
    tooltipIcon.addEventListener("mouseenter", this.showTooltip.bind(this));
    tooltipIcon.addEventListener("mouseleave", this.hideTooltip.bind(this));

    this.style.position = "relative";
    this.style.cursor = "pointer";
    this.shadowRoot.append(tooltipIcon);
  }

  showTooltip() {
    let tooltipText = "Dummy Text";
    if (this.hasAttribute("text")) {
      tooltipText = this.getAttribute("text");
    }
    this.tooltip = document.createElement("span");
    this.tooltip.innerText = tooltipText;
    this.tooltip.style.width = "max-content";
    // this.tooltip.style.display = "inline-block";
    this.tooltip.style.backgroundColor = "black";
    this.tooltip.style.color = "white";
    this.tooltip.style.border = "2px solid gray";
    this.tooltip.style.borderRadius = "5px";
    this.tooltip.style.padding = "3px";
    this.tooltip.style.position = "absolute";
    this.tooltip.style.left = "20px";
    this.tooltip.style.top = "-20px";
    this.tooltip.style.fontSize = "8px";

    this.shadowRoot.append(this.tooltip);
  }

  hideTooltip() {
    this.shadowRoot.removeChild(this.tooltip);
  }
}

customElements.define("uc-tooltip", Tooltip);
