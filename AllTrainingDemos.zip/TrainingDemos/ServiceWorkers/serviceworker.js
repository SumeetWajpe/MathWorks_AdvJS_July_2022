cachedAssets = ["Index.html", "About.html"];
self.addEventListener("install", function (e) {
  console.log("Service Worker : Installed !");

  // configure the cache !
  e.waitUntil(
    caches
      .open("C1")
      .then(cache => cache.addAll(cachedAssets))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", function (e) {
  console.log("Service Worker : Activated !");
});

self.addEventListener("fetch", function (e) {
  console.log("Service Worker : Fetching !");
  e.respondWith(fetch(e.request).catch(() => caches.match(e.request)));
});
