import * as MathModule from "./Math.js";
console.log("The addition is : " + MathModule.Add(30, 40));
console.log("The product is : " + MathModule.Product(30, 40));
